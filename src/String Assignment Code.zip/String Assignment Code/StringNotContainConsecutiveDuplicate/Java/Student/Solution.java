package StringNotContainConsecutiveDuplicate.Java.Student;

public class Solution {
	/*
	 * Take a String input from user and return a String that does not contain
	 * consecutive duplicates. For example, for input "aabccbaa" return "abcba".
	 */
	public static String notContainConsecutiveDuplicate(String str) {
		
	}

}
