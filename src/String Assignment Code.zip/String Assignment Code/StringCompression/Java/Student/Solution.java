package StringCompression.Java.Student;

public class Solution {

	public static String compress(String inputString) {

	}

}
