package StringToLowerCase.Java.Student;

public class Solution {

	public static String toLowercase(String inputString) {
		
	}

	

}
