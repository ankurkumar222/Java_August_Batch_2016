package TextPatternMatching.Java.Student;

/*
 * Given two strings S and T, write a function to find if T is present inside S. If found, return the starting position.
 * For eg. Input : S - “WelcomeBack” and T - “come”
 * Output : 3
 * 
 * 
 * */
public class Solution {
	public static int brute(String text, String pattern) {
		
	}
}
