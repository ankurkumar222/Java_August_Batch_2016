package ReverseStringWordwise.Java.Student;

/*
 * Reverse String word wise. 
 * Eg “Welcome to Coding Ninjas” reversed is – “Ninajs Coding to Welcome”
 * */
public class Solution {

	public static String reverseWordWise(String input) {
		
	}

	
}
