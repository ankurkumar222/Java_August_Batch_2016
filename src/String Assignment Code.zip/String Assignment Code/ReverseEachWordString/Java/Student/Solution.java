package ReverseEachWordString.Java.Student;

/*
 * Reverse each word of a String. 
 * Eg “Welcome to Coding Ninjas” reversed is – “emocleW ot gnidoC sajniN”
 * */
public class Solution {

	public static String reverseEachWord(String input) {
		
	}
}
