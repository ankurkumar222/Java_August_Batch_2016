package HighestOccuringCharacter.Java.Student;

// highest occurring character in the String.
public class Solution {

	public static char highestOccuringCharacter(String inputString) {

	}

}
