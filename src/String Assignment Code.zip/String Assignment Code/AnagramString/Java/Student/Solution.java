package AnagramString.Java.Student;

/*
 * Given two strings check if they are permutations of each other.
 * */
public class Solution {
	public static boolean isAnagram(String input1, String input2) {

	}

}
