package RotateStringByNCharacter.Java.Student;

public class Solution {

	public static String rotateString(String inputString, int n) {

	}

}
