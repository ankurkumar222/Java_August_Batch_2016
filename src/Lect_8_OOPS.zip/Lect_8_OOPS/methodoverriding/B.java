package Lect_8_OOPS.methodoverriding;

public class B extends A{
	void fun(){
		System.out.println("B fun()");
	}
}
