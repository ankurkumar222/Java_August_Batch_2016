package Lect_8_OOPS.methodoverriding;

public class A {

	void fun(){
		System.out.println("A fun()");
	}
}
