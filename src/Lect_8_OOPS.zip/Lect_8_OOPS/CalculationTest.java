package Lect_8_OOPS;

public class CalculationTest {

	public static void main(String[] args) {
//		Calculation cal1 = new Calculation();
//		cal1.sum(10, 20);
		//cal1.sum(10, 2, 3);
		
		Calculation.sum(10,20);
	}
}
