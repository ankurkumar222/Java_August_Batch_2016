package Lect_8_OOPS;

public class TestBox {
	public static void main(String[] args) {
//		Box b1 = new Box(10,20,30);
//		
//		int volume = b1.volume();
//		System.out.println(volume);
//		
//		
//		
//		Box b2 = new Box(1,2,3);
//		b2.depth = 40;
//		
//		
//		int volume2 = b2.volume();
//		System.out.println(volume2);
//		
//		
//		Box b3 = new Box();
		
		Box b4 = new Box(6,10);
		System.out.println(b4.height);
		
		
		Box b5 = new Box(b4);
	//	System.out.println(b5.depth+);
		
		
	}
}
