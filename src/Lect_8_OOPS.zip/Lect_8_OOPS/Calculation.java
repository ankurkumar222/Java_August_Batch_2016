package Lect_8_OOPS;

import Lect_6_Recursion.*;

public class Calculation {

	 static void  sum(int a, int b) {
		System.out.println(a + b);
	}



	void sum(int a, int b, int c) {
		System.out.println(a + b + c);
	}
	
	
	public static void main(String[] args) {
//		Calculation cal = new Calculation();
//		cal.sum(10, 20);
		sum(20,30);
		sum(10,20,30);
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
