package Lect_8_OOPS.abstractUse;

public abstract class  Bike {
	public void speed() {

	}
	
	protected abstract void applyBrakes();
}


class Honda extends Bike{

	@Override
	protected void applyBrakes() {
		// TODO Auto-generated method stub
		
	}

	
	
}