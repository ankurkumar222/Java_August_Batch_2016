package Lect_8_OOPS.accessmodifier.pack1;

public class C {
public static void main(String[] args) {
	A a = new A();
	a.fun();
	System.out.println(a.x);
}
}
