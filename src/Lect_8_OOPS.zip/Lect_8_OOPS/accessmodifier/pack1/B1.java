package Lect_8_OOPS.accessmodifier.pack1;

public class B1 extends A{
public static void main(String[] args) {
	A a = new A();

	
	
}
}
