package Lect_8_OOPS.inheritance;

public class A {

	int i;
	int j;
	void showij(){
		System.out.println(i+"  "+j);
	}
}
