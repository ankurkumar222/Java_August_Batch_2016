package Lect_8_OOPS.interfaceUse.example1;

interface Animal {
	   public void eat();
	   public void travel();
	}


class Cow implements Animal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void travel() {
		// TODO Auto-generated method stub
		
	}
	
}