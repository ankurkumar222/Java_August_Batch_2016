package Lect_8_OOPS.interfaceUse.example3;

interface A {
	void meth1();
	void meth2();
}


class Test implements A{

	@Override
	public void meth1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void meth2() {
		// TODO Auto-generated method stub
		
	}
	
}